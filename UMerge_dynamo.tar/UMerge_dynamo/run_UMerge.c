#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <argp.h>
#include <math.h>
#include <sys/resource.h>

char commandline[]= "UMerge [input_filename0] ... [input_filename_n]";

static struct argp_option options[] = {
  {"configfile", 'c', "configuration_file",    0,   "Specify name of configuration file"},
  { 0 }
};

#define MAX_NAME 1024

struct arguments{
  char config_filename[MAX_NAME];
  char** inputfns;
  char* firstfn;
  int nargs;
};

static error_t parse_opt(int key, char *arg, struct argp_state *state){
  struct arguments *arguments = state->input;  
  switch(key){
  case 'c':
    if (arg[0] != '-')
      strncpy(arguments->config_filename,arg,MAX_NAME);
    else {
      printf("arguments should not begin with a - sign.  Exiting...\n");
      exit(0);
    }
    break;
  case ARGP_KEY_ARG:
    arguments->firstfn = arg;
    arguments->nargs = state->argc - state->next;
    arguments->inputfns = &state->argv[state->next];
    state->next = state->argc;
    break;
  case ARGP_KEY_END:
    if(state->arg_num<1)
      argp_usage(state);
    break;
  default:
    return ARGP_ERR_UNKNOWN;
  }
  return 0;
}

static struct argp argp = {options,parse_opt,"$Id: UMerge_dynamo.c,v 1.0 2019-02-27 13:54:45 elyons Exp $"};

int main(int argc, char* argv[])
{

  struct arguments arguments;
  arguments.config_filename[0] = '\0';
  argp_parse(&argp,argc,argv,0,0,&arguments);
  
  /*locate and verify the config file*/
  if (arguments.config_filename[0] == '\0') {
    printf("Please specify config file with -c option.  exiting...\n");
    exit(0);
  }

  printf("config_filename: %s\n", arguments.config_filename);
  
  if(argc == 1) {
    printf("Usage: %s\n", commandline);
    exit(-1);
  }
  
  const rlim_t sSz = 64L * 1024L * 1024L;   // min stack size = 64 Mb
  struct rlimit rlim;
  int stat;

  stat = getrlimit(RLIMIT_STACK, &rlim);
  if (stat == 0) {
    if (rlim.rlim_cur < sSz) {
      rlim.rlim_cur = sSz;
      stat = setrlimit(RLIMIT_STACK, &rlim);
      if (stat != 0) {
	fprintf(stderr, "setrlimit returned result = %d\n", stat);
      }
    }
  }

  /*Function Declaration */
  void UMerge(size_t count, char* config_fn, char* i_filenames[] );
  int k;
  //printf("firstfn: %s\n", arguments.firstfn);
  //printf("inputfns: %s\n", arguments.inputfns[0]);
  //printf("n elems: %d\n", arguments.nargs);
  char** ifns = (char**) calloc(arguments.nargs + 1, sizeof(char*));
  for (k=0; k<arguments.nargs + 1; k++) {
    ifns[k] = (char*) calloc(1024, sizeof(char));
  }
  //char ifns[arguments.nargs + 1][1024];
  
  sprintf(ifns[0], "%s", arguments.firstfn);
  for (k=0; k<arguments.nargs; k++) {
    sprintf(ifns[k+1], "%s", arguments.inputfns[k]);
  }
  /*
  for (k=0; k<arguments.nargs + 1; k++) {
    printf("k: %d ifns: %s\n", k, ifns[k]);
  }
  */
  /* Function call */
  UMerge(arguments.nargs + 1, arguments.config_filename, ifns );
  
  return 0;
}






